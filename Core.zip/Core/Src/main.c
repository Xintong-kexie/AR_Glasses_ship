/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "usart.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "lcd.h"
#include "lcd_init.h"
#include "MLX90640_API.h"
#include "MLX90640_Coordinate.h"
#include "MPR121.h"
#include "pic.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define  RES16BIT   0x00
#define  RES17BIT   0x01
#define  RES18BIT   0x02
#define  RES19BIT   0x03

#define  FPS1HZ   0x01
#define  FPS2HZ   0x02
#define  FPS4HZ   0x03
#define  FPS8HZ   0x04
#define  FPS16HZ  0x05
#define  FPS32HZ  0x06

#define  TA_SHIFT 10 //Default shift for MLX90640 in open air

//#define BRIGHT_10 0
//#define BRIGHT_25 1
//#define BRIGHT_40 2
//#define BRIGHT_55 3
//#define BRIGHT_70 4
//#define BRIGHT_85 5
//#define BRIGHT_100 6

#define BRIGHT_10 0
#define BRIGHT_25 1
#define BRIGHT_50 2
#define BRIGHT_75 3
#define BRIGHT_100 4

#define TOUCH_WINDOW 4

#define DISPLAY_TEMP 0
#define DISPLAY_IMAGE 1

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t debug_text[30] = {};
uint8_t disp_text[7] = {};
uint8_t bt_text[15] = {};
int page_status;
	
uint8_t delay_count = 1;
volatile uint8_t lcd_data_count = 0, lcd_send_busy = 0;
uint32_t lcd_total_data = 0, lcd_send_length = 0;
uint8_t* lcd_cur_pic;

static uint16_t eeMLX90640[832];
static uint16_t mlx90640Frame[834];
paramsMLX90640 mlx90640;
static float mlx90640Image[768];

uint8_t color_value[24800];
	
uint16_t send_index = 0, send_times = 0;
int status;
float emissivity=0.95;

uint16_t bat_voltage_cnt = 0, adc_value;
float bat_voltage;
uint16_t mlx_i2c_addr = (0x33<<1) & 0xff;
volatile float bat_disp = 0, max_temp = 0, min_temp = 0, max_temp_processed = 0, min_temp_processed = 0;
double temp_sum = 0, avg_temp = 0;
int max_pos_x, max_pos_y, min_pos_x, min_pos_y;

float srcX, srcY, new_value;
volatile float gray_value;
uint8_t colorR, colorG, colorB;
uint16_t colorRGB;
float scaling_rate;

int srcX_l, srcX_r, srcY_u, srcY_d;
float src_X_delta, src_Y_delta;
float Ta, tr;

uint8_t temp_disp_flag = 0, temp_disp_flag_before = 0, zoom_flag = 0;

uint8_t battery_img[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xF8,0xFF,0xFF,0x03,0xFC,0xFF,0xFF,0x07,
0x0C,0x00,0x00,0x06,0xCC,0xFF,0x7F,0x1E,0xCC,0xFF,0x7F,0x1E,0xCC,0xFF,0x7F,0x1E,
0xCC,0xFF,0x7F,0x1E,0xCC,0xFF,0x7F,0x1E,0xCC,0xFF,0x7F,0x06,0x0C,0x00,0x00,0x06,
0xFC,0xFF,0xFF,0x07,0xF8,0xFF,0xFF,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

uint16_t last_touch, current_touch; 
int8_t slide_list[TOUCH_WINDOW][12] = {0,};
uint8_t hold_cnt = 0;
uint8_t slide_list_index = 0;
uint8_t touch_flag = 0;
enum Slide_DIR {
	No_act,
	Left_slide,
	Right_slide,
	Up_slide,
	Down_slide,
	Hold
};

uint8_t brightness = BRIGHT_50;
uint8_t display_interface = DISPLAY_TEMP;
uint8_t previous_display_interface = DISPLAY_TEMP;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void LCD_Send_Pic()
{
	LCD_CS_Clr();
	if(lcd_data_count != 0)
	{
		if(lcd_total_data > 65534)
		{
			lcd_total_data -= 65534;
			lcd_send_length = 65534;
		}
		else
		{
			lcd_data_count = 0;
			lcd_send_length = lcd_total_data;
		}
		HAL_SPI_Transmit_DMA(&hspi1, (uint8_t*)lcd_cur_pic, lcd_send_length);
		lcd_cur_pic += 65534;
	}
	LCD_CS_Set();
}

void LCD_Show_Pic(u16 x,u16 y,u16 length,u16 width,const u8 pic[])
{
	lcd_data_count = 1;
	lcd_total_data = length * width * 2;
	LCD_Address_Set(x, y, x+length-1, y+width-1);
	lcd_cur_pic = (uint8_t*)pic;
	LCD_Send_Pic();
}

void LCD_DrawBattery()
{
	LCD_DrawRectangle(85, 115, 107, 125, GREEN);
	LCD_DrawLine(88, 119, 101, 119, GREEN);
	LCD_DrawLine(88, 120, 101, 120, GREEN);
	LCD_DrawLine(88, 121, 101, 121, GREEN);
	LCD_DrawRectangle(107, 118, 109, 122, GREEN);
	LCD_DrawLine(108, 118, 108, 122, GREEN);
}

void temp2color_old()
{
		for(int i = 0; i < 24; i++)
		{
			for(int j = 0; j < 32; j++)
			{
				gray_value = (mlx90640Image[i*32+j] - min_temp) * scaling_rate;  // (/ 300.0 * 255)
				
				if((gray_value >= 0 && (gray_value <= 63)))
				{
					colorR = 0;
					colorG = 0;
					colorB = gray_value * 3.98;  // (/ 255.0 * 32)
				}
				else if((gray_value >= 64 && (gray_value <= 127)))
				{
					colorR = 0;
					colorG = (gray_value-64) * 3.98;
					colorB = (127-gray_value) * 3.98;
				}
				else if((gray_value >= 128 && (gray_value <= 191)))
				{
					colorR = (gray_value-128) * 3.98;
					colorG = 255;
					colorB = 0;
				}
				else if((gray_value >= 192 && (gray_value <= 255)))
				{
					colorR = 255;
					colorG = (255-gray_value) * 3.98;
					colorB = 0;
				}
				
				colorRGB = (colorR<<11) | (colorG<<5) | (colorB);
				
				color_value[send_index++] = colorRGB >> 8;
				color_value[send_index++] = colorRGB & 0xff;
			}
		}
}

void temp2color()
{	
				// ---------- Pseudo2 127 ----------
				if((gray_value >= 0 && (gray_value <= 31)))
				{
					colorR = 0;
					colorG = 0;
					colorB = gray_value;  // (/ 31.0 * 31)
				}
				else if((gray_value >= 32 && (gray_value <= 63)))
				{
					colorR = 0;
					colorG = (gray_value-32) + (gray_value-32);  // (/ 31.0 * 63)
					colorB = (63-gray_value);  // (/ 31.0 * 31)
				}
				else if((gray_value >= 64 && (gray_value <= 95)))
				{
					colorR = (gray_value-64);  // (/ 31.0 * 31)
					colorG = 63;
					colorB = 0;
				}
				else if((gray_value >= 96 && (gray_value <= 127)))
				{
					colorR = 31;
					colorG = (127-gray_value) + (127-gray_value);  // (/ 31.0 * 63)3
					colorB = 0;
				}
				// ---------- Pseudo2 127 ----------
				
				
				// ---------- Pseudo2 255 ----------
//				if((temp >= 0 && (temp <= 63)))
//				{
//					colorR = 0;
//					colorG = 0;
//					colorB = temp * 0.492;  // (/ 63.0 * 31)
//				}
//				else if((temp >= 64 && (temp <= 127)))
//				{
//					colorR = 0;
//					colorG = (temp-64);  // (/ 63.0 * 63)
//					colorB = (127-temp) * 0.492;  // (/ 63.0 * 31)
//				}
//				else if((temp >= 128 && (temp <= 191)))
//				{
//					colorR = (temp-128) * 0.492;  // (/ 63.0 * 31)
//					colorG = 63;
//					colorB = 0;
//				}
//				else if((temp >= 192 && (temp <= 255)))
//				{
//					colorR = 31;
//					colorG = (255-temp);  // (/ 63.0 * 63)
//					colorB = 0;
//				}
				// ---------- Pseudo2 255 ----------
				
				
				// ---------- Rainbow3 ----------
//				if((gray_value >= 0 && (gray_value <= 26)))
//				{
//					colorR = 0;
//					colorG = gray_value / 26.0 * 63;
//					colorB = 31;  // (/ 255.0 * 31)
//				}
//				else if((gray_value >= 27 && (gray_value <= 52)))
//				{
//					colorR = 0;
//					colorG = 63;
//					colorB = 31 - (gray_value-26) / 26.0 * 31;
//				}
//				else if((gray_value >= 53 && (gray_value <= 79)))
//				{
//					colorR = (gray_value-52) / 26.0 * 31;
//					colorG = 63;
//					colorB = 0;
//				}
//				else if((gray_value >= 80 && (gray_value <= 106)))
//				{
//					colorR = 31;
//					colorG = 63 - (gray_value-79) / 26.0 * 31;
//					colorB = 0;
//				}
//				else if(gray_value >= 107)
//				{
//					colorR = 31;
//					colorG = 0;
//					colorB = 0;
//				}
				// ---------- Rainbow3 ----------
				
				colorRGB = (colorR<<11) | (colorG<<5) | (colorB);
				color_value[send_index++] = colorRGB >> 8;
				color_value[send_index++] = colorRGB & 0xff;
				
//				if(new_value < 20)
//				{
//					color_value[send_index++] = GRAY >> 8;
//					color_value[send_index++] = GRAY & 0xff;
//				}
//				else if(new_value < 26)
//				{
//					color_value[send_index++] = BLUE >> 8;
//					color_value[send_index++] = BLUE & 0xff;
//				}
//				else if(new_value < 28)
//				{
//					color_value[send_index++] = GREEN >> 8;
//					color_value[send_index++] = GREEN & 0xff;
//				}
//				else if(new_value < 30)
//				{
//					color_value[send_index++] = YELLOW >> 8;
//					color_value[send_index++] = YELLOW & 0xff;
//				}
//				else
//				{
//					color_value[send_index++] = RED >> 8;
//					color_value[send_index++] = RED & 0xff;
//				}
}

enum Slide_DIR Touch_Pad(void)
{
	int16_t vector[12] = {0,};
	
	for(int i=0;i<12;i++)
	{
		for(int j=0;j<TOUCH_WINDOW;j++)
		{
			vector[i] += slide_list[j][i];	//���㻬������;(?
		}
	}
	if((vector[7]+vector[11])>0 && (vector[4]+vector[8])<0)		//����۲촰ʱ���ڣ��û������������һ�λ���������λ����Ϣ
	{
		memset(slide_list,	0,sizeof(slide_list));//��������λ
		hold_cnt=0;
		__HAL_TIM_SET_PRESCALER(&htim7,250-1);
		return Left_slide;
	}
	if((vector[7]+vector[11])<0 && (vector[4]+vector[8])>0)		//ͬ��
	{
		memset(slide_list,	0,sizeof(slide_list));//��������λ
		hold_cnt=0;
		__HAL_TIM_SET_PRESCALER(&htim7,250-1);
		return Right_slide;
	}
	if(hold_cnt>=100)		//��߳���
	{
		memset(slide_list,	0,sizeof(slide_list));//��������λ
		hold_cnt=0;
		__HAL_TIM_SET_PRESCALER(&htim7,250-1);
		return Hold;
	}
//	if((vector[0]+vector[1]+vector[2]+vector[3])>0 && (vector[8]+vector[9]+vector[10]+vector[11])<0)
//	{
//		memset(slide_list,	0,sizeof(slide_list));//��������λ
//		__HAL_TIM_SET_PRESCALER(&htim7,250-1);
//		return Up_slide;
//	}
//	if((vector[0]+vector[1]+vector[2]+vector[3])<0 && (vector[4]+vector[5]+vector[6]+vector[7])>0)
//	{
//		memset(slide_list,	0,sizeof(slide_list));//��������λ
//		__HAL_TIM_SET_PRESCALER(&htim7,250-1);
//		return Down_slide;
//	}
	
	return No_act;
}

void LCD_Set_Brightness(int bright)
{
//	if(bright == BRIGHT_10)
//		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 50-1);
//	else if(bright == BRIGHT_25)
//		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 125-1);
//	else if(bright == BRIGHT_55)
//		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 275-1);
//	else if(bright == BRIGHT_70)
//		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 350-1);
//	else if(bright == BRIGHT_85)
//		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 425-1);
//	else if(bright == BRIGHT_100)
//		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 500-1);
//	else // BRIGHT_40
//		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 200-1);
	
	if(bright == BRIGHT_10)
		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 50-1);
	else if(bright == BRIGHT_25)
		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 125-1);
	else if(bright == BRIGHT_75)
		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 375-1);
	else if(bright == BRIGHT_100)
		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 500-1);
	else // BRIGHT_50
		__HAL_TIM_SetCompare(&htim16, TIM_CHANNEL_1, 250-1);
}

void Touch_handler()
{
	if(touch_flag)
	{
		touch_flag = 0;
		switch(Touch_Pad())
		{
			case Right_slide:
				brightness = (brightness<BRIGHT_100) ? (brightness + 1) : BRIGHT_100;
				LCD_Set_Brightness(brightness);
				printf("left slide!\n");
				break;
			case Left_slide:
				brightness = (brightness>BRIGHT_10) ? (brightness - 1) : BRIGHT_10;
				LCD_Set_Brightness(brightness);
				printf("right slide!\n");
				break;
			case Hold:
				previous_display_interface = display_interface;
				display_interface = (display_interface + 1) % 2;
// ---------------- zoom code hided in MLX90640_Coordinate.h and main function in main.c ----------------
//				zoom_flag = !zoom_flag;
//				printf("right hold!\n");
				break;
			default:
				;
		}
	}
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_LPUART1_UART_Init();
  MX_SPI1_Init();
  MX_I2C2_Init();
  MX_TIM16_Init();
  MX_ADC1_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  MX_TIM7_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_PWM_Start(&htim16, TIM_CHANNEL_1);
	LCD_Set_Brightness(BRIGHT_50);
	HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);
	HAL_ADC_Start(&hadc1);
	
	printf("AR_Glasses\n");
	LCD_Init();
	HAL_Delay(1);
//	LCD_Init();
//	HAL_Delay(1);
	LCD_Fill(0,0,LCD_W,LCD_H,BLACK);
	LCD_DrawBattery();
	
//	HAL_UART_Receive_IT(&hlpuart1, debug_text, 1);
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)"AT+VER=?\r\n", strlen("AT+VER=?\r\n"), 100);
//	HAL_Delay(500);
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)"AT+SLEEPEN=1\r\n", strlen("AT+SLEEPEN=1\r\n"), 100);
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)"AT+NAME=AR_GLASSES\r\n", strlen("AT+NAME=AR_GLASSES\r\n"), 100);
//	HAL_Delay(500);
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)"AT+NAME=?\r\n", strlen("AT+NAME=?\r\n"), 100);
	
//	while(1)
//	{
//		HAL_UART_Transmit(&hlpuart1, (uint8_t *)"BLE_Test\n", strlen("BLE_Test\n"), 100);
//		HAL_Delay(500);
//	}
//	printf(debug_text);
//	HAL_Delay(1000);
//	printf("Transmit_End\n");

	adc_value = HAL_ADC_GetValue(&hadc1);
	bat_voltage = adc_value / 4095.0 * 3.3 * 2.0075;
	bat_disp = (bat_voltage*1.8 - 6.4)*100;
	if(bat_disp > 100)
		bat_disp = 100.0;
	else if(bat_disp < 0)
		bat_disp = 0.0;
	
	sprintf((char*)disp_text, "%2.0f%%", bat_disp);
	LCD_ShowString(89, 100, disp_text, GREEN, BLACK, 12, 0);
	HAL_ADC_Start(&hadc1);

	LCD_ShowString(25, 100, (uint8_t*)"MAX", GREEN, BLACK, 12, 0);
	LCD_ShowString(25, 115, (uint8_t*)"MIN", GREEN, BLACK, 12, 0);

	MLX90640_SetResolution(mlx_i2c_addr, RES19BIT);
	MLX90640_SetRefreshRate(mlx_i2c_addr, FPS16HZ);
	MLX90640_SetChessMode(mlx_i2c_addr);
	
	status = MLX90640_DumpEE(mlx_i2c_addr, eeMLX90640);
  if (status != 0)
		printf("DumpEE error with code:%d\n",status);
  status = MLX90640_ExtractParameters(eeMLX90640, &mlx90640);
  if (status != 0)
		printf("ExtractParameters error with code:%d\n",status);
	
	MPR121_Init();
	HAL_TIM_Base_Start_IT(&htim7);
  /* USER CODE END 2 */

  /* Infinite loop */ 
  /* USER CODE BEGIN WHILE */
	//16bits 
	//0000 0000 0000 0000   LSB -> MSB order
	//---- ---							��ɫ
	//        - ----				��ɫ
	//            -- ----		��ɫ
	
//	while(1)
//	{
//		LCD_Fill(0,0,LCD_W,LCD_H,RED);
//		LCD_Fill(0,0,LCD_W,LCD_H,BLUE);
//	}
	
  while (1)
  {
		if (display_interface == DISPLAY_IMAGE && previous_display_interface != DISPLAY_IMAGE)
		{
			HAL_Delay(50); // important, avoid DMA from collision
			LCD_Fill(0,0,LCD_W,LCD_H,BLACK);
			LCD_DrawBattery();
			
			adc_value = HAL_ADC_GetValue(&hadc1);
			bat_voltage = adc_value / 4095.0 * 3.3 * 2.0075;
			bat_disp = (bat_voltage*1.8 - 6.4)*100;
			if(bat_disp > 100)
				bat_disp = 100.0;
			else if(bat_disp < 0)
				bat_disp = 0.0;
			
			sprintf((char*)disp_text, "%2.0f%%", bat_disp);
			LCD_ShowString(89, 100, disp_text, GREEN, BLACK, 12, 0);
			HAL_Delay(10);
			
			//LCD_ShowPicture(20,10,90,90,gImage_uestc);
			//LCD_ShowPicture(15,10,100,100,gImage_xtkx);
			LCD_ShowPicture(10,10,100,80,gImage_ship);
			
			previous_display_interface = DISPLAY_IMAGE;
		}
		else if(display_interface == DISPLAY_IMAGE)
		{
			HAL_Delay(50);
		}
		else if (display_interface == DISPLAY_TEMP)
		{
			if (previous_display_interface == DISPLAY_IMAGE)
			{
				LCD_ShowString(25, 100, (uint8_t*)"MAX", GREEN, BLACK, 12, 0);
				LCD_ShowString(25, 115, (uint8_t*)"MIN", GREEN, BLACK, 12, 0);
				previous_display_interface = DISPLAY_TEMP;
			}
			
			status = MLX90640_GetFrameData(mlx_i2c_addr, mlx90640Frame);
			if(status < 0)
				printf("GetFrame Error: %d\n",status);
			
			Ta = MLX90640_GetTa(mlx90640Frame, &mlx90640);
			tr = Ta - TA_SHIFT; //Reflected temperature based on the sensor ambient temperature

			MLX90640_CalculateTo(mlx90640Frame, &mlx90640, emissivity , tr, mlx90640Image);
			MLX90640_BadPixelsCorrection((&mlx90640)->brokenPixels, mlx90640Image, 1, &mlx90640);
			MLX90640_BadPixelsCorrection((&mlx90640)->outlierPixels, mlx90640Image, 1, &mlx90640);
			
			max_temp = -40;
			min_temp = 300;
			temp_sum = 0;
			for(int i = 0; i < 24; i++)
			{
				for(int j = 0; j < 32; j++)
				{
					temp_sum += mlx90640Image[i*32+j];
					if(mlx90640Image[i*32+j] > max_temp)
						max_temp = mlx90640Image[i*32+j];
					if(mlx90640Image[i*32+j] < min_temp)
						min_temp = mlx90640Image[i*32+j];
				}
			}
			
			if(max_temp <= -40 || min_temp >= 300)
				NVIC_SystemReset();
			
			if(max_temp > 300)
				max_temp = 300.0;
			else if(max_temp < -40)
				max_temp = -40.0;
			
			if(min_temp > 300)
				min_temp = 300.0;
			else if(min_temp < -40)
				min_temp = -40.0;
			
			send_index = 0;
			send_times = 0;
	//		scaling_rate = 255.0 / (max_temp - min_temp);
			scaling_rate = 127.0 / (max_temp - min_temp);
			
			max_temp_processed = 0;
			min_temp_processed = 300;
			for(int i = 0; i < 92; i++)
			{
				for(int j = 127; j >= 0; j--)
				{
	//				srcX = (i + 0.5) * 0.25 - 0.5;
	//				srcY = (j + 0.5) * 0.25 - 0.5;
					
// ---------------- zoom code hided in MLX90640_Coordinate.h and main function in main.c ----------------
//					if(zoom_flag == 1)
//					{
//						srcX = srcX_pre_zoomed[i*128+j];  // 20*15
//						srcY = srcY_pre_zoomed[i*128+j];
//					}
//					else
//					{
						srcX = srcX_pre[i*128+j];  // 32*24
						srcY = srcY_pre[i*128+j];
//					}
					srcX_l = (int)srcX;
					srcY_u = (int)srcY;
					srcX_r = srcX_l + 1;
					srcY_d = srcY_u + 1;
					
					new_value = (srcX_r - srcX)*(srcY_d - srcY)*mlx90640Image[srcX_l*32+srcY_u]
																+ (srcX_r - srcX)*(srcY - srcY_u)*mlx90640Image[srcX_l*32+srcY_d]
																+ (srcX - srcX_l)*(srcY_d - srcY)*mlx90640Image[srcX_r*32+srcY_u]
																+ (srcX - srcX_l)*(srcY - srcY_u)*mlx90640Image[srcX_r*32+srcY_d];
					gray_value = (new_value - min_temp) * scaling_rate;
					
					if(new_value > max_temp_processed)
					{
						max_temp_processed = new_value;
						max_pos_x = j;
						max_pos_y = i;
					}
					if(new_value < min_temp_processed)
					{
						min_temp_processed = new_value;
						min_pos_x = j;
						min_pos_y = i;
					}
					
					temp2color();
				}
			}

			// Cold_disp
			int min_disp_pos = (min_pos_y*128+127-min_pos_x)*2;
			for(int i=-12; i<=13; i++)
			{
				if((min_disp_pos+i)>=256)
					color_value[min_disp_pos+i-256] = 0xFF;
				color_value[min_disp_pos+i] = 0xFF;
				if((min_disp_pos+i+256)<=24576)
				color_value[min_disp_pos+i+256] = 0xFF;
			}
			for(int i=-6; i<=6; i++)
			{
				for(int j=-2; j<=3; j++)
				{
					if((min_disp_pos+j+i*256)>=0 && (min_disp_pos+j+i*256)<=24576)
						color_value[min_disp_pos+j+i*256] = 0xFF;
				}
			}

			sprintf((char*)disp_text, "%-5.1f", min_temp);
			LCD_ShowString(50, 115, disp_text, GREEN, BLACK, 12, 0);
			
			// Hot_disp
			int max_disp_pos = (max_pos_y*128+127-max_pos_x)*2;
			for(int i=-12; i<=13; i++)
			{
				if((max_disp_pos+i)>=256)
					color_value[max_disp_pos+i-256] = 0x00;
				color_value[max_disp_pos+i] = 0x00;
				if((max_disp_pos+i+256)<=24576)
				color_value[max_disp_pos+i+256] = 0x00;
			}
			for(int i=-6; i<=6; i++)
			{
				for(int j=-2; j<=3; j++)
				{
					if((max_disp_pos+j+i*256)>=0 && (max_disp_pos+j+i*256)<=24576)
						color_value[max_disp_pos+j+i*256] = 0x00;
				}
			}

			sprintf((char*)disp_text, "%-5.1f", max_temp);
			LCD_ShowString(50, 100, disp_text, GREEN, BLACK, 12, 0);
				
			// Bluetooth
			if((bat_voltage_cnt%10) == 0)
			{
	//			sprintf((char*)bt_text, "%.1f", max_temp);
				sprintf((char*)bt_text, "%.1f&%.1f", max_temp, min_temp);
				HAL_UART_Transmit_DMA(&hlpuart1, (uint8_t *)bt_text, strlen((char*)bt_text));
			}
			
			lcd_send_busy = 1;
	//		LCD_Show_Pic(32,24,32,24,color_value);
			LCD_Show_Pic(0,0,128,92,color_value);
		}
		
		if(bat_voltage_cnt < 200)
				bat_voltage_cnt++;
		else
		{
			LCD_Init();
			HAL_Delay(1);
//			LCD_Init();
//			HAL_Delay(1);
			LCD_Fill(0,0,LCD_W,LCD_H,BLACK);
			LCD_DrawBattery();
			
			if (display_interface == DISPLAY_TEMP)
			{
				LCD_ShowString(25, 100, (uint8_t*)"MAX", GREEN, BLACK, 12, 0);
				LCD_ShowString(25, 115, (uint8_t*)"MIN", GREEN, BLACK, 12, 0);
			}
			
			if (display_interface == DISPLAY_IMAGE)
				previous_display_interface = DISPLAY_TEMP;
			
			adc_value = HAL_ADC_GetValue(&hadc1);
			bat_voltage = adc_value / 4095.0 * 3.3 * 2.0075;
			bat_disp = (bat_voltage*1.8 - 6.4)*100;
			if(bat_disp > 100)
				bat_disp = 100.0;
			else if(bat_disp < 0)
				bat_disp = 0.0;
			
			sprintf((char*)disp_text, "%2.0f%%", bat_disp);
			LCD_ShowString(89, 100, disp_text, GREEN, BLACK, 12, 0);
			bat_voltage_cnt = 0;
			HAL_ADC_Start(&hadc1);
		}
		
		Touch_handler();
	}
	/* USER CODE END WHILE */
	/* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	printf((char*)debug_text);
//	HAL_UART_Transmit(&hlpuart1, (uint8_t *)"Receive\r\n", strlen("Receive\r\n"), 100);
	HAL_UART_Receive_IT(&hlpuart1, debug_text, 1);
}

int fputc(int ch,FILE *f)
{
    HAL_UART_Transmit(&huart1 , (uint8_t *)&ch , 1 , 0xffff);
    return ch;
}

void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
	if(lcd_data_count != 0)
		LCD_Send_Pic();
	
	if(lcd_data_count == 0)
		lcd_send_busy = 0;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim == &htim7)
	{
		current_touch = MPR121_Start();	//���մ���������
		for(int i=0;i<12;i++)	//���������� ÿ������ �ı仯����������
		{
			if(((current_touch&(0x01<<i))-(last_touch&(0x01<<i)))==0)
			{
				slide_list[slide_list_index][i] = 0;
			}
			else if(((current_touch&(0x01<<i))-(last_touch&(0x01<<i)))>0)
			{
				slide_list[slide_list_index][i] = 1;
			}
			else if(((current_touch&(0x01<<i))-(last_touch&(0x01<<i)))<0)
			{
				slide_list[slide_list_index][i] = -1;
			}
		}
		if(current_touch&((0x1<<4)+(0x1<<8)+(0x1<<7)))
		{
			hold_cnt++;	//�����ۼ�
		}else	hold_cnt=0;
		last_touch = current_touch;	//��¼����״̬
		slide_list_index = slide_list_index==TOUCH_WINDOW-1 ? 0 : slide_list_index+1;	//ѭ�����и���
		
		touch_flag = 1; //�������λ��λ
		__HAL_TIM_SET_PRESCALER(&htim7,30-1);
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
