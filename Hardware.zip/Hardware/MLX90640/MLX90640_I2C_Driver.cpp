/**
 * @copyright (C) 2017 Melexis N.V.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <stdio.h>
#include "i2c.h"
#include "MLX90640_I2C_Driver.h"

int MLX90640_I2CRead(uint8_t slaveAddr, uint16_t startAddress, uint16_t nMemAddressRead, uint16_t *data)
{
	uint8_t* p = (uint8_t*) data;
	
	int ack = HAL_I2C_Mem_Read(&hi2c2, slaveAddr, startAddress, I2C_MEMADD_SIZE_16BIT, p, nMemAddressRead*2, 500);
	if (ack != HAL_OK)
			return -1;
	
	for(int cnt = 0; cnt < nMemAddressRead*2; cnt += 2)
	{
		uint8_t tempBuffer = p[cnt+1];
		p[cnt+1] = p[cnt];
		p[cnt] = tempBuffer;
	}

	return 0;
}


int MLX90640_I2CWrite(uint8_t slaveAddr, uint16_t writeAddress, uint16_t data)
{
	uint8_t cmd[2];
	cmd[0] = data >> 8;
	cmd[1] = data & 0x00FF;
//	static uint16_t dataCheck;
	
	int ack = HAL_I2C_Mem_Write(&hi2c2, slaveAddr, writeAddress, I2C_MEMADD_SIZE_16BIT, cmd, sizeof(cmd), 500);
	if (ack != HAL_OK)
			return -1;
	
//	MLX90640_I2CRead(slaveAddr,writeAddress,1, &dataCheck);
//	
//	if (dataCheck != data)
//			return -2;
	
	return 0;
}

