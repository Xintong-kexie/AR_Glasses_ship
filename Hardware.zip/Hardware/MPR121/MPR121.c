#include "MPR121.h"
#include "i2c.h"
void MPR121Write(uint8_t address, uint8_t data)
{
	HAL_I2C_Mem_Write(MPRI2C, MPR121_ADD, address, I2C_MEMADD_SIZE_8BIT, &data, 1, 0x100);
}
uint8_t MPR121Read(uint8_t address)
{
	uint8_t data;
	HAL_I2C_Mem_Read(MPRI2C, MPR121_ADD, address, I2C_MEMADD_SIZE_8BIT, &data, 1, 0x100);
	return data;
}
void MPR121_Init(void)
{
    //��λ MPR121
    MPR121Write(0x80, 0x63);    //����λ���ٷ�ָ��д��0x63ֵ��   
    MPR121Write(0x5E, 0x00);    //ֹͣģʽ
   
    // Section A  // ������ƹ��ˡ� data is > baseline.
    MPR121Write(MHD_R, 0x01);
    MPR121Write(NHD_R, 0x01);
    MPR121Write(NCL_R, 0x00);
    MPR121Write(FDL_R, 0x00);

    // Section B  // ������ƹ��ˡ�data is < baseline.
    MPR121Write(MHD_F, 0x01);
    MPR121Write(NHD_F, 0x01);
    MPR121Write(NCL_F, 0xFF);
    MPR121Write(FDL_F, 0x00);
    
    //���߹��˿��ƼĴ���
    MPR121Write(0x33, 0x00);    //noise half delta touched
    MPR121Write(0x34, 0x00);    //noise counts touched
    MPR121Write(0x35, 0x00);    //filter delay touched

    MPR121Write(0x36, 0x0F);
    MPR121Write(0x37, 0x0F);
    MPR121Write(0x38, 0x00);
    MPR121Write(0x39, 0x00);
    MPR121Write(0x3A, 0x01);
    MPR121Write(0x3B, 0x01);
    MPR121Write(0x3C, 0xFF);
    MPR121Write(0x3D, 0xFF);
    MPR121Write(0x3E, 0x00);
    MPR121Write(0x3F, 0x00);
    MPR121Write(0x40, 0x00);
        
    // Section C  // ����Ϊÿ���缫���ô������ͷ���ֵ
    MPR121Write(ELE0_T, TOU_THRESH);
    MPR121Write(ELE0_R, REL_THRESH);
    MPR121Write(ELE1_T, TOU_THRESH);
    MPR121Write(ELE1_R, REL_THRESH);
    MPR121Write(ELE2_T, TOU_THRESH);
    MPR121Write(ELE2_R, REL_THRESH);
    MPR121Write(ELE3_T, TOU_THRESH);
    MPR121Write(ELE3_R, REL_THRESH);
    MPR121Write(ELE4_T, TOU_THRESH);
    MPR121Write(ELE4_R, REL_THRESH);
    MPR121Write(ELE5_T, TOU_THRESH);
    MPR121Write(ELE5_R, REL_THRESH);
    MPR121Write(ELE6_T, TOU_THRESH);
    MPR121Write(ELE6_R, REL_THRESH);
    MPR121Write(ELE7_T, TOU_THRESH);
    MPR121Write(ELE7_R, REL_THRESH);
    MPR121Write(ELE8_T, TOU_THRESH);
    MPR121Write(ELE8_R, REL_THRESH);
    MPR121Write(ELE9_T, TOU_THRESH);
    MPR121Write(ELE9_R, REL_THRESH);
    MPR121Write(ELE10_T, TOU_THRESH);
    MPR121Write(ELE10_R, REL_THRESH);
    MPR121Write(ELE11_T, TOU_THRESH);
    MPR121Write(ELE11_R, REL_THRESH);

    MPR121Write(0x59, 0x02);
    MPR121Write(0x5A, 0x01);
    MPR121Write(0x5B, 0x00);
    MPR121Write(0x5C, 0x10);
    MPR121Write(0x5D, 0x24);
    
    // �����Զ����ú��Զ���������
    MPR121Write(0x7B, 0x0B);
    MPR121Write(0x7D, 0xC8);
    MPR121Write(0x7E, 0x82);
    MPR121Write(0x7F, 0xB4);

    //�缫���ã���Ҫ��
    MPR121Write(0x5E, 0xBC);//1011,1100�����û��߸��٣����ýӽ���⣬��������12���缫
}
//��ȡ������Ϣ��12��ͨ���ֱ��Ӧǰ12��bit��1Ϊ���£�0Ϊ�ɿ�
uint16_t MPR121_Start(void)
{
	uint16_t data;
	data = MPR121Read(0x00) + (MPR121Read(0x01)<<8);
	return data&0x0fff;
}
