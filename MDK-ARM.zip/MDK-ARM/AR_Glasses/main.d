ar_glasses/main.o: ..\Core\Src\main.c ..\Core\Inc\main.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal.h \
  ..\Core\Inc\stm32l4xx_hal_conf.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_def.h \
  ..\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l4xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l431xx.h \
  ..\Drivers\CMSIS\Include\core_cm4.h \
  D:\Program_Files\Arm\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\Drivers\CMSIS\Include\cmsis_version.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  D:\Program_Files\Arm\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_compat.h \
  D:\Program_Files\Arm\Keil_v5\ARM\ARMCLANG\Bin\..\include\arm_acle.h \
  ..\Drivers\CMSIS\Include\mpu_armv7.h \
  ..\Drivers\CMSIS\Device\ST\STM32L4xx\Include\system_stm32l4xx.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  D:\Program_Files\Arm\Keil_v5\ARM\ARMCLANG\Bin\..\include\stddef.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_dma.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_cortex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_adc.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_ll_adc.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_adc_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_exti.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ramfunc.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_i2c.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_i2c_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_spi.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_spi_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_tim.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_tim_ex.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_uart.h \
  ..\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_uart_ex.h \
  ..\Core\Inc\adc.h ..\Core\Inc\main.h ..\Core\Inc\dma.h \
  ..\Core\Inc\i2c.h ..\Core\Inc\usart.h ..\Core\Inc\spi.h \
  ..\Core\Inc\tim.h ..\Core\Inc\gpio.h \
  D:\Program_Files\Arm\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdio.h \
  D:\Program_Files\Arm\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  D:\Program_Files\Arm\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h \
  ..\Core\Inc\lcd.h ..\Core\Inc\lcd_init.h \
  ..\Hardware\MLX90640\MLX90640_API.h \
  ..\Hardware\MLX90640\MLX90640_Coordinate.h ..\Hardware\MPR121\MPR121.h \
  ..\Core\Inc\pic.h
